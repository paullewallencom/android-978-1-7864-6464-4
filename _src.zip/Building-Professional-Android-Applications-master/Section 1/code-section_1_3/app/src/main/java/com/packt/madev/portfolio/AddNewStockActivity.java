package com.packt.madev.portfolio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.packt.madev.R;

public class AddNewStockActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.portfolio_activity_add_new_stock);
    }
}
