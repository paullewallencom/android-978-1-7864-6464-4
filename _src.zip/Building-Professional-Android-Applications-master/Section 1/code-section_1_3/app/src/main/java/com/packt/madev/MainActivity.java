package com.packt.madev;

import com.packt.madev.portfolio.StockPortfolioListActivity;

public class MainActivity extends StockPortfolioListActivity {

}
