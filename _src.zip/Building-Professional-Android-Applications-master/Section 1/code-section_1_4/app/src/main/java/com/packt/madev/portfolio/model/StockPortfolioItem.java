package com.packt.madev.portfolio.model;

public class StockPortfolioItem {
    private String symbol;

    public StockPortfolioItem(String symbol) {
        this.symbol = symbol;
    }

    public String getSymbol() {
        return symbol;
    }
}
