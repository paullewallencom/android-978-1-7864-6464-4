package com.packt.madev;

import com.packt.madev.portfolio.list.StockPortfolioListViewActivity;

public class MainActivity extends StockPortfolioListViewActivity {

}
